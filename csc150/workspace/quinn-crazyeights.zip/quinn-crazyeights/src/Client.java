
public class Client {

    /**
     * Xavier Quinn
     * 
     * I affirm that I have carried out the attached academic endeavors with full academic honesty, in
     * accordance with the Union College Honor Code and the course syllabus.
     */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CrazyEights game = new CrazyEights();
		game.playGame();

	}

}
