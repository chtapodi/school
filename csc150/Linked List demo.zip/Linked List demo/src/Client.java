import javabook.*;
public class Client {

	public static void main(String[] args) {
		InputBox inbox = new InputBox();
		LinkedList L = new LinkedList();
		
		for (int i=1; i<=5; i++) {
			int someNum = inbox.getInteger("number? ");
			L.insertAtHead(someNum);
			System.out.println("after insertion #" + i + ":"); 
			System.out.println(L);
		}
	}

}
