/**
 * The Listnode class is more data-specific than the LinkedList class.
 * It specifies what a single node (single piece of data) looks like.
 * 
 * This is the ONLY class where I'll let you use public instance variables.
 *
 */
public class Listnode {

	public int content;
	public Listnode next;
	
	/**
	 * default constructor
	 * @param new_content new data to insert
	 */
	public Listnode(int new_content) {
		content = new_content;
		next = null;
	}
	
	/**
	 * 
	 * @return data stored in this node
	 */
	public int getContent() {
		return content;
	}
	
	public String toString() {
		return "" + content;
	}
}









