/**
 * The LinkedList class gives you access to the beginning of the linked list
 * through a private instance variable called firstNode. This class contains
 * all of the methods for general manipulation of the list: traversal,
 * insertion, deletion, searching, etc.
 */
public class LinkedList {

	private Listnode firstNode;
	private int length;
	
	/**
	 *  Default constructor
	 */
	public LinkedList() {
		length = 0;
		firstNode = null;
	}
	
	/**
	 * inserts data as first node in the LL
	 * @param data content of new node
	 */
	public void insertAtHead(int data){
		Listnode myNode = new Listnode(data);
		if (isEmpty()){
			firstNode = myNode;
		}
		else {
//			firstNode = myNode;  // can't do this first!  Order matters!
			myNode.next = firstNode;
			firstNode = myNode;
		}
		length++;
		// if empty
		//   make length go up by 1
		//   build a node with data
		//   make firstNode point to that new node
		// else (not empty)
		//   make length go up by 1
		//   build a node with data
		//   make firstnode point to new node
		//   update new node's next pt to be the orig firstnode
	}
	
	public String toString() {
		String toReturn = "{";
		Listnode runner = firstNode;
		while (runner != null) {
			toReturn = toReturn + runner.toString();
			// if we are not at the last node, add a comma
			if (runner.next != null) {
				toReturn+=", ";
			}
//			toReturn = toReturn + runner.content;  //not reusable
			runner = runner.next;
		}
		toReturn+="}";
		return toReturn;
	}
	
	/**
	 * 
	 * @return the number of items in this list
	 */
	public int getLength(){
		return length;
	}
	
	/**
	 * 
	 * @return true if list empty, else false
	 */
	public boolean isEmpty() {
		return this.getLength() == 0;
	}
}
